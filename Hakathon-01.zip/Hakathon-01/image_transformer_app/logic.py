import cv2
import numpy as np
 
class ImageProcessor:
    def __init__(self, image):
        self.original = image.copy()
        self.image = image.copy()
 
    def reset(self):
        self.image = self.original.copy()
        return self.image
 
    def to_grayscale(self):
        if len(self.image.shape) == 3:
            self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        return self.image
 
    def gaussian_blur(self, ksize=5):
        if ksize % 2 == 0:
            ksize += 1  # Ensure odd
        self.image = cv2.GaussianBlur(self.image, (ksize, ksize), 0)
        return self.image
 
    def median_blur(self, ksize=5):
        if ksize % 2 == 0:
            ksize += 1  # Must be odd
        self.image = cv2.medianBlur(self.image, ksize)
        return self.image
 
    def sobel_edge(self):
        gray = self.image if len(self.image.shape) == 2 else cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        sobel = cv2.Sobel(gray, cv2.CV_64F, 1, 1, ksize=5)
        self.image = cv2.convertScaleAbs(sobel)
        return self.image
 
    def canny_edge(self, threshold1=100, threshold2=200):
        gray = self.image if len(self.image.shape) == 2 else cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        self.image = cv2.Canny(gray, threshold1, threshold2)
        return self.image
 
    def threshold(self):
        gray = self.image if len(self.image.shape) == 2 else cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        _, self.image = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
        return self.image
 
    def rotate(self, angle=90):
        (h, w) = self.image.shape[:2]
        M = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
        self.image = cv2.warpAffine(self.image, M, (w, h))
        return self.image
 
    def resize(self, fx=0.5, fy=0.5):
        self.image = cv2.resize(self.image, None, fx=fx, fy=fy)
        return self.image
 
    def erosion(self, ksize=3):
        kernel = np.ones((ksize, ksize), np.uint8)
        self.image = cv2.erode(self.image, kernel, iterations=1)
        return self.image
 
    def dilation(self, ksize=3):
        kernel = np.ones((ksize, ksize), np.uint8)
        self.image = cv2.dilate(self.image, kernel, iterations=1)
        return self.image
 
    def adjust_brightness(self, value=0):
        if len(self.image.shape) == 2:
            self.image = cv2.cvtColor(self.image, cv2.COLOR_GRAY2BGR)
        hsv = cv2.cvtColor(self.image, cv2.COLOR_BGR2HSV)
        h, s, v = cv2.split(hsv)
        v = cv2.add(v, value)
        v = np.clip(v, 0, 255)
        hsv = cv2.merge((h, s, v))
        self.image = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
        return self.image
 
    def adjust_contrast(self, factor=1.0):
        if len(self.image.shape) == 2:
            self.image = cv2.cvtColor(self.image, cv2.COLOR_GRAY2BGR)
        self.image = cv2.convertScaleAbs(self.image, alpha=factor, beta=0)
        return self.image
 
    def flip(self, mode=1):  # 0: vertical, 1: horizontal, -1: both
        self.image = cv2.flip(self.image, mode)
        return self.image