# client.py
import socket
import json
import requests

API_KEY = "86cddbc4b114539b8223adc0f0ea152c"
BASE_URL = "http://api.openweathermap.org/data/2.5/weather"
SERVER_IP = "192.168.1.50"  # Replace with your Raspberry Pi IP
PORT = 12345

def get_weather(city_name):
    try:
        params = {
            "q": f"{city_name},IN",
            "appid": API_KEY,
            "units": "metric"
        }
        response = requests.get(BASE_URL, params=params)
        data = response.json()

        if response.status_code != 200 or 'main' not in data:
            print(f"❌ Error: {data.get('message', 'Unknown error')}")
            return None

        return {
            "temp": data["main"]["temp"],
            "pressure": data["main"]["pressure"],
            "condition": data["weather"][0]["main"]
        }

    except Exception as e:
        print(f"❌ Exception: {e}")
        return None

def send_to_server(data):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((SERVER_IP, PORT))
            s.sendall(json.dumps(data).encode())
            print("✅ Weather data sent to Raspberry Pi.")
    except Exception as e:
        print('\n')
        print(f"❌ Socket Error: {e}")

if __name__ == "__main__":
   if __name__ == "__main__":
    CITY = input("🏙️ Enter city name: ")
    weather = get_weather(CITY)

    if weather:
        print("📦 Weather Data Ready to Send:", weather)
        send_to_server(weather)
    else:
        print("🚫 Weather data not available, aborting.")