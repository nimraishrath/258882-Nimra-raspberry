# server.py
import socket
import json
from gpiozero import LED
from time import sleep

THRESHOLD = 30  # °C
PORT = 12345
led = LED(26)

def display_weather(data):
    print("\n📡 Received Weather Data:")
    print(f"🌡️ Temperature: {data['temp']}°C")
    print(f"📈 Pressure: {data['pressure']} hPa")
    print(f"🌥️ Condition: {data['condition']}")

def control_led(temp):
    if temp > THRESHOLD:
        led.on()
        print("🔴 LED ON: Temperature exceeds threshold!")
    else:
        led.off()
        print("🟢 LED OFF: Temperature is normal.")

def start_server():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', PORT))
        s.listen(1)
        print("🚀 Server is listening for incoming connections...")
        conn, addr = s.accept()
        with conn:
            print(f"✅ Connected by {addr}")
            data = conn.recv(1024)
            if data:
                try:
                    weather = json.loads(data.decode())
                    display_weather(weather)
                    control_led(weather['temp'])
                except (json.JSONDecodeError, KeyError):
                    print("❌ Invalid data received.")

if __name__ == "__main__":
    while True:
        start_server()
        sleep(1)
