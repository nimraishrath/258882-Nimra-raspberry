import sys
import cv2
from PyQt5.QtWidgets import QApplication, QFileDialog, QMessageBox
from PyQt5.QtGui import QImage, QPixmap
from gui import Ui_MainWindow
from logic import ImageProcessor
from PyQt5.QtWidgets import QMainWindow
 
class ImageApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.processor = None
 
        # Connect buttons
        self.ui.btnUpload.clicked.connect(self.load_image)
        self.ui.btnSave.clicked.connect(self.save_image)
        self.ui.btnReset.clicked.connect(self.reset_image)
 
        # Transform buttons
        self.ui.btnGray.clicked.connect(lambda: self.apply("to_grayscale"))
        self.ui.btnGaussian.clicked.connect(lambda: self.apply("gaussian_blur"))
        self.ui.btnMedian.clicked.connect(lambda: self.apply("median_blur"))
        self.ui.btnSobel.clicked.connect(lambda: self.apply("sobel_edge"))
        self.ui.btnCanny.clicked.connect(lambda: self.apply("canny_edge"))
        self.ui.btnThreshold.clicked.connect(lambda: self.apply("threshold"))
        self.ui.btnRotate.clicked.connect(lambda: self.apply("rotate"))
        self.ui.btnResize.clicked.connect(lambda: self.apply("resize"))
        self.ui.btnErode.clicked.connect(lambda: self.apply("erosion"))
        self.ui.btnDilate.clicked.connect(lambda: self.apply("dilation"))
        self.ui.btnFlip.clicked.connect(lambda: self.apply("flip"))
 
        # Connect sliders for live updates
        self.ui.sliderBrightness.valueChanged.connect(self.change_brightness)
        self.ui.sliderContrast.valueChanged.connect(self.change_contrast)
 
    def load_image(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open Image", "", "Images (*.png *.jpg *.bmp)")
        if path:
            image = cv2.imread(path)
            if image is None:
                QMessageBox.critical(self, "Error", "Failed to open image.")
                return
            self.processor = ImageProcessor(image)
            self.show_image(self.processor.image)
            self.ui.sliderBrightness.setValue(0)
            self.ui.sliderContrast.setValue(0)
 
    def show_image(self, img):
        if len(img.shape) == 2:
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        h, w, ch = img.shape
        bytes_per_line = ch * w
        qimg = QImage(img.data, w, h, bytes_per_line, QImage.Format_RGB888)
        self.ui.imageLabel.setPixmap(QPixmap.fromImage(qimg).scaled(self.ui.imageLabel.size(), aspectRatioMode=1))
 
    def apply(self, operation):
        if self.processor:
            method = getattr(self.processor, operation)
            result = method()
            self.show_image(result)
 
    def change_brightness(self):
        if self.processor:
            value = self.ui.sliderBrightness.value()  # -100 to 100
            img = self.processor.adjust_brightness(value)
            self.show_image(img)
 
    def change_contrast(self):
        if self.processor:
            value = self.ui.sliderContrast.value()  # -100 to 100
            factor = 1 + (value / 100.0)
            img = self.processor.adjust_contrast(factor)
            self.show_image(img)
 
    def reset_image(self):
        if self.processor:
            self.processor.reset()
            self.show_image(self.processor.image)
            self.ui.sliderBrightness.setValue(0)
            self.ui.sliderContrast.setValue(0)
 
    def save_image(self):
        if self.processor:
            path, _ = QFileDialog.getSaveFileName(self, "Save Image", "", "PNG Files (*.png);;JPG Files (*.jpg)")
            if path:
                cv2.imwrite(path, self.processor.image)
                QMessageBox.information(self, "Saved", "Image saved successfully.")
 
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ImageApp()
    window.show()
    sys.exit(app.exec_())